/*import React, { Component } from 'react';

class Table_had extends Component {
    render() {
        return (
            <table>
                <thead>
                    <tr>
                        <th>Student_name_had</th>
                        <th>Roll_no</th>
                        <th>Class</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Gunveen</td>
                        <td>368</td>
                        <td>syit</td>
                    </tr>
                    <tr>
                        <td>simran</td>
                        <td>300</td>
                        <td>syit</td>
                    </tr>
                </tbody>
            </table>
        )
    }
}

const Table = () => {
    return (
        <h1>Some sample text</h1>
    );
}

export default Table_had;
export { Table}
*/